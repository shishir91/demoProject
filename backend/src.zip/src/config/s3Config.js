const { S3Client } = require("@aws-sdk/client-s3");

const s3 = new S3Client({
  region: "us-east-1", // Scality uses any region
  endpoint: process.env.S3_ENDPOINT, // Set your Scality S3 endpoint
  forcePathStyle: true, // Required for Scality
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

module.exports = s3;
